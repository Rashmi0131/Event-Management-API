﻿namespace EventManagementAPICRUD.Models
{
    public class SearchEvent
    {
        public string? Name { get; set; }
        public string? Location { get; set; }
        public DateTime? Date { get; set; }
    }
}
